package @portlet.java.package.name@

import com.liferay.util.bridges.mvc.MVCPortlet

class @portlet.java.class.name@Portlet extends MVCPortlet
